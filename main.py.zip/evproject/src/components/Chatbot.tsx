import { useState } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  text: string;
  isBot: boolean;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { text: "Hi! I'm your EV Assistant. Ask me anything about electric vehicles!", isBot: true }
  ]);
  const [input, setInput] = useState("");

  const responses: { [key: string]: string } = {
    hi: "Hello! What do you want to know about EV cars?",
    hello: "Hello! What do you want to know about EV cars?",
    hey: "Hello! What do you want to know about EV cars?",
    "thank you": "You're welcome and see you later!",
    thanks: "You're welcome and see you later!",
    "thank": "You're welcome and see you later!",
    bye: "See you later! Feel free to come back if you have more questions.",
    range: "EV range depends on battery capacity, driving conditions, and motor efficiency. Most modern EVs offer 250-400 km on a single charge.",
    battery: "Battery capacity is measured in kWh. Higher capacity means longer range but also higher cost. Most EVs have 40-100 kWh batteries.",
    charge: "Fast charging can charge an EV to 80% in 30-60 minutes. Home charging typically takes 6-8 hours for a full charge.",
    price: "EV prices vary based on brand, battery size, and features. Entry-level EVs start around ₹10-15 lakhs, while premium models can exceed ₹50 lakhs.",
    motor: "Motor power (measured in kW) affects acceleration and top speed. Most EVs have 50-200 kW motors.",
    default: "That's a great question! EVs are the future of sustainable transportation. They offer lower running costs, zero emissions, and a smooth driving experience."
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = { text: input, isBot: false };
    setMessages(prev => [...prev, userMessage]);

    const lowerInput = input.toLowerCase();
    let botResponse = responses.default;

    for (const [key, value] of Object.entries(responses)) {
      if (lowerInput.includes(key)) {
        botResponse = value;
        break;
      }
    }

    setTimeout(() => {
      setMessages(prev => [...prev, { text: botResponse, isBot: true }]);
    }, 500);

    setInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Bot with Label */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-center gap-2">
        {!isOpen ? (
          <>
            <div 
              onClick={() => setIsOpen(true)}
              className="text-7xl cursor-pointer hover:scale-110 transition-transform animate-float"
              role="button"
              aria-label="Open EV Bot"
            >
              🤖
            </div>
            <div className="bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-lg text-sm font-semibold whitespace-nowrap">
              Ask our EV Bot
            </div>
          </>
        ) : (
          <Button
            onClick={() => setIsOpen(false)}
            className="h-16 w-16 rounded-full shadow-2xl hover:scale-110 transition-transform"
            size="icon"
          >
            <X className="h-7 w-7" />
          </Button>
        )}
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 sm:w-96 h-[500px] bg-card rounded-2xl shadow-2xl border border-border z-50 flex flex-col animate-slide-up">
          {/* Header */}
          <div className="hero-gradient text-primary-foreground p-4 rounded-t-2xl">
            <h3 className="font-semibold text-lg">Ask EV Assistant</h3>
            <p className="text-sm opacity-90">Get instant answers about EVs</p>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-3">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.isBot ? "justify-start" : "justify-end"} animate-fade-in`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl ${
                      msg.isBot
                        ? "bg-muted text-foreground"
                        : "bg-primary text-primary-foreground"
                    }`}
                  >
                    <p className="text-sm">{msg.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about EVs..."
                className="flex-1"
              />
              <Button onClick={handleSend} size="icon">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
