import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Battery, Zap, Clock, Car, Mail, ArrowDown, TrendingUp, Users, Globe, BarChart3 } from "lucide-react";
import Chatbot from "@/components/Chatbot";
import Navbar from "@/components/Navbar";
import { toast } from "@/hooks/use-toast";
import evHeroBackground from "@/assests/ev-hero-background.jpg";

const Index = () => {
  const [formData, setFormData] = useState({
    brand: "",
    model: "",
    battery: "",
    range: "",
    motor: "",
    chargeTime: "",
    seats: "",
    weight: "",
  });

  const [prediction, setPrediction] = useState<{
    price: number;
    estimatedRange: number;
    vehicleSize: string;
  } | null>(null);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculatePrediction = () => {
    const battery = parseFloat(formData.battery) || 0;
    const motor = parseFloat(formData.motor) || 0;
    const weight = parseFloat(formData.weight) || 0;

    if (!formData.brand || !formData.model || battery === 0) {
      toast({
        title: "Missing Information",
        description: "Please fill in at least Brand, Model, and Battery Capacity.",
        variant: "destructive",
      });
      return;
    }

    const basePrice = 1000000; // Base price ₹10 lakhs
    const randomFactor = Math.random() * 40000 + 10000;
    const price = Math.round(basePrice + (battery * 150000) / 100 + motor * 800 + randomFactor);
    
    const estimatedRange = Math.round(battery * 20 + motor * 2);
    
    let vehicleSize = "Compact";
    if (weight > 2000) vehicleSize = "Truck";
    else if (weight > 1600) vehicleSize = "SUV";
    else if (weight > 1200) vehicleSize = "Sedan";

    setPrediction({ price, estimatedRange, vehicleSize });
    
    toast({
      title: "Prediction Complete!",
      description: "Scroll down to see your results.",
    });
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen gradient-bg">
      {/* Navbar */}
      <Navbar />
      
      {/* Hero Section */}
      <section id="hero" className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${evHeroBackground})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background"></div>
        </div>
        <div className="container max-w-5xl text-center relative z-10 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Predict the Price and Range of Your Electric Vehicle
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Get instant insights into cost, performance, and energy efficiency with our AI-powered predictions.
          </p>
          <Button 
            size="lg" 
            className="text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all animate-float"
            onClick={() => scrollToSection("prediction")}
          >
            Get Started
            <ArrowDown className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Prediction Form Section */}
      <section id="prediction" className="py-20 px-4">
        <div className="container max-w-4xl mx-auto">
          <Card className="glass-card shadow-2xl animate-slide-up">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl md:text-4xl font-bold mb-2">
                EV Prediction Tool
              </CardTitle>
              <CardDescription className="text-lg">
                Enter your vehicle specifications to get instant predictions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="brand">Brand *</Label>
                  <Select onValueChange={(value) => handleInputChange("brand", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select brand" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Tata">Tata</SelectItem>
                      <SelectItem value="MG">MG</SelectItem>
                      <SelectItem value="Tesla">Tesla</SelectItem>
                      <SelectItem value="Hyundai">Hyundai</SelectItem>
                      <SelectItem value="Kia">Kia</SelectItem>
                      <SelectItem value="BYD">BYD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="model">Model *</Label>
                  <Input
                    id="model"
                    placeholder="e.g., Nexon EV"
                    value={formData.model}
                    onChange={(e) => handleInputChange("model", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="battery">Battery Capacity (kWh) *</Label>
                  <Input
                    id="battery"
                    type="number"
                    placeholder="e.g., 50"
                    value={formData.battery}
                    onChange={(e) => handleInputChange("battery", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="range">Range (km)</Label>
                  <Input
                    id="range"
                    type="number"
                    placeholder="e.g., 400"
                    value={formData.range}
                    onChange={(e) => handleInputChange("range", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="motor">Motor Power (kW)</Label>
                  <Input
                    id="motor"
                    type="number"
                    placeholder="e.g., 100"
                    value={formData.motor}
                    onChange={(e) => handleInputChange("motor", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="chargeTime">Charge Time (mins)</Label>
                  <Input
                    id="chargeTime"
                    type="number"
                    placeholder="e.g., 60"
                    value={formData.chargeTime}
                    onChange={(e) => handleInputChange("chargeTime", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seats">Seats</Label>
                  <Input
                    id="seats"
                    type="number"
                    placeholder="e.g., 5"
                    value={formData.seats}
                    onChange={(e) => handleInputChange("seats", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weight">Curb Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 1500"
                    value={formData.weight}
                    onChange={(e) => handleInputChange("weight", e.target.value)}
                  />
                </div>
              </div>

              <Button 
                className="w-full text-lg py-6 shadow-lg hover:shadow-xl transition-all" 
                size="lg"
                onClick={calculatePrediction}
              >
                Predict Now
              </Button>

              {prediction && (
                <div className="mt-8 p-6 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl border-2 border-primary/20 animate-slide-up">
                  <h3 className="text-2xl font-bold mb-4 text-center">Your Prediction Results</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-card rounded-lg">
                      <p className="text-muted-foreground mb-2">Estimated Price</p>
                      <p className="text-3xl font-bold text-primary">
                        ₹{(prediction.price / 100000).toFixed(2)}L
                      </p>
                    </div>
                    <div className="text-center p-4 bg-card rounded-lg">
                      <p className="text-muted-foreground mb-2">Estimated Range</p>
                      <p className="text-3xl font-bold text-secondary">
                        {prediction.estimatedRange} km
                      </p>
                    </div>
                    <div className="text-center p-4 bg-card rounded-lg">
                      <p className="text-muted-foreground mb-2">Vehicle Size</p>
                      <p className="text-3xl font-bold text-accent">
                        {prediction.vehicleSize}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-card/30">
        <div className="container max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">About Electric Vehicles</h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            The future of transportation is electric. Discover how EVs are transforming mobility worldwide.
          </p>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="glass-card">
              <CardHeader>
                <Globe className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Global EV Market</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  The global electric vehicle market is experiencing exponential growth. Over 10 million EVs were sold worldwide in 2022, with projections reaching 30+ million by 2030.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• China leads with 60% of global EV sales</li>
                  <li>• Europe accounts for 25% of the market</li>
                  <li>• USA shows rapid adoption with 10% market share</li>
                  <li>• 500+ EV models available globally</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-secondary mb-2" />
                <CardTitle>EV Market in India</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  India's EV market is growing at 90% annually. The government aims for 30% EV penetration by 2030, supported by policies like FAME II scheme and state-level subsidies.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• 1.5 million EVs sold in India (2023)</li>
                  <li>• Tata Motors leads with 75% market share</li>
                  <li>• Over 12,000 public charging stations</li>
                  <li>• ₹11,500 Cr government incentives allocated</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader>
                <BarChart3 className="h-12 w-12 text-accent mb-2" />
                <CardTitle>Growing Demand</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Rising fuel costs, environmental awareness, and improving infrastructure are driving unprecedented EV adoption rates globally.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• 70% reduction in running costs vs petrol</li>
                  <li>• Zero tailpipe emissions</li>
                  <li>• Lower maintenance requirements</li>
                  <li>• Government incentives & tax benefits</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader>
                <Users className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Future Outlook</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  By 2030, EVs are expected to represent 40% of new vehicle sales globally. Battery technology improvements promise 600+ km ranges at affordable prices.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• 50% cost reduction in batteries by 2030</li>
                  <li>• Ultra-fast charging in 10-15 minutes</li>
                  <li>• Autonomous EV fleets emerging</li>
                  <li>• Vehicle-to-grid integration</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Insights Section */}
      <section id="insights" className="py-20 px-4">
        <div className="container max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-4">Market Insights</h2>
          <p className="text-muted-foreground mb-12 max-w-2xl mx-auto">
            Key statistics and trends shaping the electric vehicle revolution
          </p>
          
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="glass-card">
              <CardContent className="pt-6">
                <div className="text-4xl font-bold text-primary mb-2">10M+</div>
                <p className="text-sm text-muted-foreground">Global EV Sales (2022)</p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-6">
                <div className="text-4xl font-bold text-secondary mb-2">90%</div>
                <p className="text-sm text-muted-foreground">Annual Growth in India</p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-6">
                <div className="text-4xl font-bold text-accent mb-2">30%</div>
                <p className="text-sm text-muted-foreground">Target EV Share by 2030</p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-6">
                <div className="text-4xl font-bold text-primary mb-2">70%</div>
                <p className="text-sm text-muted-foreground">Lower Running Costs</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* EV Details Section */}
      <section id="details" className="py-20 px-4 bg-muted/30">
        <div className="container max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Understanding EV Specifications</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="glass-card hover:shadow-xl transition-all hover:-translate-y-2">
              <CardHeader>
                <Battery className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Battery Capacity</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Measured in kWh, determines how far your EV can travel on a single charge. Larger batteries offer more range.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card hover:shadow-xl transition-all hover:-translate-y-2">
              <CardHeader>
                <Car className="h-12 w-12 text-secondary mb-2" />
                <CardTitle>Range</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Total distance an EV can travel on a full charge. Affected by battery size, driving style, and conditions.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card hover:shadow-xl transition-all hover:-translate-y-2">
              <CardHeader>
                <Zap className="h-12 w-12 text-accent mb-2" />
                <CardTitle>Motor Power</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Measured in kW, determines acceleration and performance. Higher power means better performance but may reduce efficiency.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card hover:shadow-xl transition-all hover:-translate-y-2">
              <CardHeader>
                <Clock className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Charge Time</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Time needed to fully charge. Fast chargers can reach 80% in 30-60 minutes, while home charging takes 6-8 hours.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="container max-w-2xl mx-auto text-center">
          <Card className="glass-card shadow-xl">
            <CardHeader>
              <Mail className="h-16 w-16 mx-auto text-primary mb-4" />
              <CardTitle className="text-3xl mb-2">Contact & Support</CardTitle>
              <CardDescription className="text-lg">
                Have questions about electric vehicles or our prediction tool?
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-lg mb-4">
                Reach out to us at{" "}
                <a 
                  href="https://mail.google.com/mail/?view=cm&to=evsupport@example.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary font-semibold hover:underline"
                >
                  evsupport@example.com
                </a>
              </p>
              <p className="text-muted-foreground">
                We're here to help you make informed decisions about your electric vehicle journey.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border bg-card/50">
        <div className="container max-w-6xl mx-auto text-center">
          <p className="text-muted-foreground">
            Built for EV Vehicles and Price Prediction Insights © 2025
          </p>
        </div>
      </footer>

      {/* Chatbot */}
      <Chatbot />
    </div>
  );
};

export default Index;
