import React, { useState } from 'react';

const ContactCard: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // For now, just log. You can integrate backend later
    console.log('Contact Form Submitted:', { name, email, message });
    alert('Thank you! Your message has been sent.');
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <div style={{
      maxWidth: '400px',
      margin: 'auto',
      padding: '20px',
      borderRadius: '12px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      backgroundColor: '#ffffff'
    }}>
      <h2 style={{ textAlign: 'center', marginBottom: '15px' }}>Contact Us</h2>

      <p style={{ textAlign: 'center' }}>
        For support, email us at{' '}
        <a href="mailto:support@yourdomain.com" style={{ color: '#1E90FF', textDecoration: 'none' }}>
          support@yourdomain.com
        </a>
      </p>

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '20px' }}>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ccc' }}
        />
        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ccc' }}
        />
        <textarea
          placeholder="Your Message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
          style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ccc', minHeight: '80px' }}
        />
        <button
          type="submit"
          style={{
            padding: '10px',
            borderRadius: '6px',
            border: 'none',
            backgroundColor: '#1E90FF',
            color: '#fff',
            fontWeight: 'bold',
            cursor: 'pointer'
          }}
        >
          Send Message
        </button>
      </form>
    </div>
  );
};

export default ContactCard;
